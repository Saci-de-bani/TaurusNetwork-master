Masternode Budget API
=======================

Budgets will begin block 345,200.  For information on how this will work, please see pivx-doc/masternode-budget.md
